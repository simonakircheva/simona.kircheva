package TestRunner;

import cucumber.api.CucumberOptions;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@CucumberOptions(features="Features",glue= "test.project.test", plugin = "json:target/cucumber-report.json")						
public class TestRunner extends AbstractTestNGCucumberTests{
}
