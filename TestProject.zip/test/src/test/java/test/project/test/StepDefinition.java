package test.project.test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
@Test
public class StepDefinition {
	
	WebDriver driver;
	Actions actions;
	
	@Given("^Open Chrome and launch the application$")
	public void open_Chrome_and_launch_the_application() {
		try {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\simona\\Desktop\\chromedriver.exe");
		 driver = new ChromeDriver();
		 actions = new Actions(driver);
		driver.get("http://www.amazon.co.uk");
		 
		  WebElement menu = driver.findElement(By.id("nav-hamburger-menu"));	
			 menu.click();
			 driver.manage().timeouts().implicitlyWait(5,TimeUnit.SECONDS) ;
			 WebElement element = driver.findElement(By.xpath("//ul[@class='hmenu  hmenu-visible']//a[@class='hmenu-item']//div[contains(text(),'Electronics & Computers')]"));
			 actions.moveToElement(element);
			 element.click();
			 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
			 driver.manage().window().maximize();
			 WebElement laptops = driver.findElement(By.xpath("//a[@class='hmenu-item']/div[contains(text(),'Laptops')]"));
			 actions.moveToElement(laptops);
			 laptops.click();
			 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;			 
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@When("^Select Display Size (\\d+)\"(.*?)\"$")
	public void select_Display_Size(int arg1, String arg2) throws Throwable {	
		try {
		 WebElement displaySize = driver.findElement(By.xpath("//input[@name='s-ref-checkbox-182753031']"));
		 displaySize.click();
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@When("^Select CPU Type - Intel Core i(\\d+)$")
	public void select_CPU_Type_Intel_Core_i(int arg1) throws Throwable {	
		try {
		 WebElement cpu = driver.findElement(By.xpath("//span[text()='Intel Core i5']"));
		 cpu.click();	
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@When("^Select Storage Type SSD$")
	public void select_Storage_Type_SSD() throws Throwable {	
		try {
		 WebElement storage = driver.findElement(By.xpath("//span[text()='SSD']"));
		 storage.click(); 
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Select a five stared Laptop with the lowest price$")
	public void select_a_five_stared_Laptop_with_the_lowest_price() throws Throwable {		
		try {
		 WebElement rating = driver.findElement(By.xpath("//i[@class='a-icon a-icon-star-medium a-star-medium-4']"));
		 rating.click(); 
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		 WebElement sort = driver.findElement(By.id("a-autoid-0-announce"));
		 sort.click(); 
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		 WebElement price = driver.findElement(By.id("s-result-sort-select_1"));
		 price.click();
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		 WebElement result = driver.findElement(By.xpath("//span[text()='Dell Inspiron i7559-763BLK 15.6\" Full-HD Gaming Laptop US Layout Keyboard (Core i5, 8GB RAM, 256GB SSD, NVIDIA GeForce GTX960M) with Windows 10']"));
		 result.click(); 
		 driver.manage().timeouts().implicitlyWait(15,TimeUnit.SECONDS) ;
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

	@Then("^Verify it's the selected laptop$")
	public void verify_it_s_the_selected_laptop() throws Throwable {
		try {
		WebElement laptop = driver.findElement(By.id("productTitle"));
		 String laptopResult = laptop.getText();
		 Assert.assertEquals("Dell Inspiron i7559-763BLK 15.6\" Full-HD Gaming Laptop US Layout Keyboard (Core i5, 8GB RAM, 256GB SSD, NVIDIA GeForce GTX960M) with Windows 10",laptopResult);
		 driver.quit();
	}catch(Exception e) {
		e.printStackTrace();
		driver.quit();
	}
	    
	}
	
	
}
